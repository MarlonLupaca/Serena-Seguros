-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: serena-mysql-replica    Database: bd_seguros_pacifico
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '20dcc5b6-50b0-11f1-9885-c6f4e5d513fc:1-5,
20ea0799-50b0-11f1-97e7-b2245f35aa60:1-77';

--
-- Table structure for table `activo_interno`
--

DROP TABLE IF EXISTS `activo_interno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activo_interno` (
  `id_activo` int NOT NULL AUTO_INCREMENT,
  `id_empleado_asignado` int DEFAULT NULL,
  `tipo` varchar(100) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `valor_depreciacion` decimal(10,2) NOT NULL,
  `estado` enum('OPERATIVO','MANTENIMIENTO','BAJA') NOT NULL DEFAULT 'OPERATIVO',
  PRIMARY KEY (`id_activo`),
  KEY `id_empleado_asignado` (`id_empleado_asignado`),
  CONSTRAINT `activo_interno_ibfk_1` FOREIGN KEY (`id_empleado_asignado`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activo_interno`
--

LOCK TABLES `activo_interno` WRITE;
/*!40000 ALTER TABLE `activo_interno` DISABLE KEYS */;
INSERT INTO `activo_interno` VALUES (1,1,'Laptop','Lenovo ThinkPad',3500.00,'OPERATIVO'),(2,1,'Monitor','Dell P2422H',1200.00,'OPERATIVO'),(3,1,'Impresora','HP LaserJet',2100.00,'MANTENIMIENTO'),(4,1,'Vehículo','Toyota Yaris',55000.00,'OPERATIVO'),(5,1,'Servidor','HP ProLiant',12000.00,'OPERATIVO');
/*!40000 ALTER TABLE `activo_interno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aprobacion_critica`
--

DROP TABLE IF EXISTS `aprobacion_critica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aprobacion_critica` (
  `id_aprobacion` int NOT NULL AUTO_INCREMENT,
  `modulo_origen` varchar(100) NOT NULL,
  `monto_impacto` decimal(12,2) NOT NULL,
  `comentarios_previos` text,
  `estado_gerencial` enum('PENDIENTE','APROBADO','RECHAZADO') NOT NULL DEFAULT 'PENDIENTE',
  `fecha_solicitud` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_aprobacion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aprobacion_critica`
--

LOCK TABLES `aprobacion_critica` WRITE;
/*!40000 ALTER TABLE `aprobacion_critica` DISABLE KEYS */;
INSERT INTO `aprobacion_critica` VALUES (1,'SINIESTROS',45000.00,'Reclamo por accidente vehicular - revisar documentos del taller','PENDIENTE','2026-05-15 22:49:09'),(2,'REASEGURO',120000.00,'Renovacion contrato con Mapfre Re - condiciones modificadas','PENDIENTE','2026-05-15 22:49:09'),(3,'COMPRAS',18500.00,'Compra de servidores para la sede secundaria','PENDIENTE','2026-05-15 22:49:09'),(4,'CAMPANAS',9500.00,'Pauta digital Q4 - Facebook y Google Ads','PENDIENTE','2026-05-15 22:49:09'),(5,'COMISIONES',32000.00,'Bonificacion extraordinaria a equipo comercial por cierre de Q3','PENDIENTE','2026-05-15 22:49:09');
/*!40000 ALTER TABLE `aprobacion_critica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asiento_contable`
--

DROP TABLE IF EXISTS `asiento_contable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asiento_contable` (
  `id_asiento` int NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `total_debe` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_haber` decimal(12,2) NOT NULL DEFAULT '0.00',
  `estado` enum('ABIERTO','CERRADO') NOT NULL DEFAULT 'ABIERTO',
  PRIMARY KEY (`id_asiento`),
  KEY `idx_asiento_fecha` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asiento_contable`
--

LOCK TABLES `asiento_contable` WRITE;
/*!40000 ALTER TABLE `asiento_contable` DISABLE KEYS */;
INSERT INTO `asiento_contable` VALUES (1,'2026-04-25','Cobro primas Enero',8500.00,8500.00,'CERRADO'),(2,'2026-05-05','Cobro primas Febrero',9200.00,9200.00,'CERRADO'),(3,'2026-04-30','Pago alquiler oficina',3200.00,3200.00,'CERRADO'),(4,'2026-05-07','Pago sueldos demo',12500.00,12500.00,'CERRADO'),(5,'2026-05-12','Provision proveedor',1500.00,1500.00,'CERRADO');
/*!40000 ALTER TABLE `asiento_contable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria_accion`
--

DROP TABLE IF EXISTS `auditoria_accion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria_accion` (
  `id_auditoria` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `accion` varchar(80) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `detalle` text,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_auditoria`),
  KEY `idx_auditoria_fecha` (`fecha`),
  KEY `idx_auditoria_usuario` (`id_usuario`),
  CONSTRAINT `auditoria_accion_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_accion`
--

LOCK TABLES `auditoria_accion` WRITE;
/*!40000 ALTER TABLE `auditoria_accion` DISABLE KEYS */;
INSERT INTO `auditoria_accion` VALUES (1,NULL,'admin_demo','LOGIN','SISTEMA','Acción de auditoría automática','2026-05-15 22:49:09'),(2,NULL,'admin_demo','CREAR_POLIZA','SISTEMA','Acción de auditoría automática','2026-05-15 22:49:09'),(3,NULL,'admin_demo','APROBAR_PAGO','SISTEMA','Acción de auditoría automática','2026-05-15 22:49:09'),(4,NULL,'admin_demo','DESCARGAR_DOC','SISTEMA','Acción de auditoría automática','2026-05-15 22:49:09'),(5,NULL,'admin_demo','LOGOUT','SISTEMA','Acción de auditoría automática','2026-05-15 22:49:09'),(6,NULL,NULL,'planilla_procesada','nomina','Periodo 2026-05 · 4 empleados · neto 10270.80','2026-05-15 22:49:10');
/*!40000 ALTER TABLE `auditoria_accion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `beneficiario`
--

DROP TABLE IF EXISTS `beneficiario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `beneficiario` (
  `id_beneficiario` int NOT NULL AUTO_INCREMENT,
  `id_persona` int NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `parentesco` varchar(50) NOT NULL,
  `documento_identidad` varchar(20) DEFAULT NULL,
  `porcentaje` decimal(5,2) NOT NULL DEFAULT '100.00',
  PRIMARY KEY (`id_beneficiario`),
  KEY `id_persona` (`id_persona`),
  CONSTRAINT `beneficiario_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beneficiario`
--

LOCK TABLES `beneficiario` WRITE;
/*!40000 ALTER TABLE `beneficiario` DISABLE KEYS */;
INSERT INTO `beneficiario` VALUES (1,1,'Lucia','Asegurada Perez','Hija','20000001',40.00),(2,1,'Mateo','Asegurado Perez','Hijo','20000002',30.00),(3,1,'Pedro','Asegurado Senior','Padre','20000003',10.00),(4,1,'Rosa','Familiar Lima','Madre','20000004',10.00),(5,1,'Camila','Asegurada Joven','Hermana','20000005',10.00);
/*!40000 ALTER TABLE `beneficiario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campana_marketing`
--

DROP TABLE IF EXISTS `campana_marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campana_marketing` (
  `id_campana` int NOT NULL AUTO_INCREMENT,
  `id_empleado_agente` int NOT NULL,
  `asunto` varchar(200) NOT NULL,
  `plantilla` text NOT NULL,
  `enviados` int DEFAULT '0',
  `abiertos` int DEFAULT '0',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_campana`),
  KEY `id_empleado_agente` (`id_empleado_agente`),
  CONSTRAINT `campana_marketing_ibfk_1` FOREIGN KEY (`id_empleado_agente`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campana_marketing`
--

LOCK TABLES `campana_marketing` WRITE;
/*!40000 ALTER TABLE `campana_marketing` DISABLE KEYS */;
INSERT INTO `campana_marketing` VALUES (1,1,'Renueva tu SOAT con 15% dscto','Renueva antes del vencimiento y obten un descuento del 15%.',320,145,'2026-05-15 22:49:10'),(2,1,'Salud familiar - mes gratis','Contrata salud premium en familia y recibe un mes sin costo.',280,95,'2026-05-15 22:49:10'),(3,1,'Vida + Ahorro = Tranquilidad','Conoce nuestro plan de vida con ahorro respaldado.',410,180,'2026-05-15 22:49:10'),(4,1,'Hogar protegido al 100%','Cobertura total para tu casa y contenido. Aprovecha ahora.',195,60,'2026-05-15 22:49:10'),(5,1,'Viaja seguro al exterior','Cobertura internacional desde S/ 120.',360,210,'2026-05-15 22:49:10');
/*!40000 ALTER TABLE `campana_marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `id_persona` int NOT NULL,
  `estado_crm` enum('NUEVO','CONTACTADO','CLIENTE','INACTIVO') NOT NULL DEFAULT 'NUEVO',
  `fecha_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `id_persona` (`id_persona`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,1,'CLIENTE','2026-05-15 22:49:09'),(2,6,'CLIENTE','2026-05-15 22:49:10'),(3,7,'CLIENTE','2026-05-15 22:49:10'),(4,8,'CLIENTE','2026-05-15 22:49:10'),(5,9,'CLIENTE','2026-05-15 22:49:10');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comision_agente`
--

DROP TABLE IF EXISTS `comision_agente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comision_agente` (
  `id_comision` int NOT NULL AUTO_INCREMENT,
  `id_empleado_agente` int NOT NULL,
  `id_poliza` int NOT NULL,
  `porcentaje` decimal(5,2) NOT NULL,
  `monto_generado` decimal(10,2) NOT NULL,
  `estado_pago` enum('PENDIENTE','PAGADA') NOT NULL DEFAULT 'PENDIENTE',
  PRIMARY KEY (`id_comision`),
  KEY `id_empleado_agente` (`id_empleado_agente`),
  KEY `id_poliza` (`id_poliza`),
  CONSTRAINT `comision_agente_ibfk_1` FOREIGN KEY (`id_empleado_agente`) REFERENCES `empleado` (`id_empleado`),
  CONSTRAINT `comision_agente_ibfk_2` FOREIGN KEY (`id_poliza`) REFERENCES `poliza` (`id_poliza`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comision_agente`
--

LOCK TABLES `comision_agente` WRITE;
/*!40000 ALTER TABLE `comision_agente` DISABLE KEYS */;
INSERT INTO `comision_agente` VALUES (1,1,1,5.00,75.00,'PAGADA'),(2,1,2,5.00,180.00,'PAGADA'),(3,1,3,5.00,12.50,'PENDIENTE');
/*!40000 ALTER TABLE `comision_agente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_contable`
--

DROP TABLE IF EXISTS `cuenta_contable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuenta_contable` (
  `id_cuenta` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `tipo` enum('ACTIVO','PASIVO','PATRIMONIO','INGRESO','GASTO') NOT NULL,
  PRIMARY KEY (`id_cuenta`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_contable`
--

LOCK TABLES `cuenta_contable` WRITE;
/*!40000 ALTER TABLE `cuenta_contable` DISABLE KEYS */;
INSERT INTO `cuenta_contable` VALUES (1,'1010','Caja y bancos','ACTIVO'),(2,'1210','Cuentas por cobrar','ACTIVO'),(3,'2010','Cuentas por pagar','PASIVO'),(4,'3010','Capital social','PATRIMONIO'),(5,'4010','Ingresos por primas','INGRESO'),(6,'5010','Gastos operativos','GASTO'),(7,'5020','Gastos de personal','GASTO');
/*!40000 ALTER TABLE `cuenta_contable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuota_cobranza`
--

DROP TABLE IF EXISTS `cuota_cobranza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuota_cobranza` (
  `id_cuota` int NOT NULL AUTO_INCREMENT,
  `id_poliza` int NOT NULL,
  `numero_cuota` int NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `estado_pago` enum('PENDIENTE','PAGADO','VENCIDO') NOT NULL DEFAULT 'PENDIENTE',
  PRIMARY KEY (`id_cuota`),
  KEY `id_poliza` (`id_poliza`),
  CONSTRAINT `cuota_cobranza_ibfk_1` FOREIGN KEY (`id_poliza`) REFERENCES `poliza` (`id_poliza`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuota_cobranza`
--

LOCK TABLES `cuota_cobranza` WRITE;
/*!40000 ALTER TABLE `cuota_cobranza` DISABLE KEYS */;
INSERT INTO `cuota_cobranza` VALUES (1,1,1,125.00,'2026-03-15','PAGADO'),(2,1,2,125.00,'2026-04-15','PAGADO'),(3,1,3,125.00,'2026-05-15','PENDIENTE'),(4,1,4,125.00,'2026-06-15','PENDIENTE'),(5,1,5,125.00,'2026-07-15','PENDIENTE'),(6,1,6,125.00,'2026-08-15','PENDIENTE'),(7,1,7,125.00,'2026-09-15','PENDIENTE'),(8,1,8,125.00,'2026-10-15','PENDIENTE'),(9,1,9,125.00,'2026-11-15','PENDIENTE'),(10,1,10,125.00,'2026-12-15','PENDIENTE'),(11,1,11,125.00,'2027-01-15','PENDIENTE'),(12,1,12,125.00,'2027-02-15','PENDIENTE'),(13,2,1,300.00,'2026-04-15','PAGADO'),(14,2,2,300.00,'2026-05-15','PENDIENTE'),(15,2,3,300.00,'2026-06-15','PENDIENTE'),(16,2,4,300.00,'2026-07-15','PENDIENTE'),(17,2,5,300.00,'2026-08-15','PENDIENTE'),(18,2,6,300.00,'2026-09-15','PENDIENTE'),(19,2,7,300.00,'2026-10-15','PENDIENTE'),(20,2,8,300.00,'2026-11-15','PENDIENTE'),(21,2,9,300.00,'2026-12-15','PENDIENTE'),(22,2,10,300.00,'2027-01-15','PENDIENTE'),(23,2,11,300.00,'2027-02-15','PENDIENTE'),(24,2,12,300.00,'2027-03-15','PENDIENTE');
/*!40000 ALTER TABLE `cuota_cobranza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_planilla`
--

DROP TABLE IF EXISTS `detalle_planilla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_planilla` (
  `id_detalle` int NOT NULL AUTO_INCREMENT,
  `id_planilla` int NOT NULL,
  `id_empleado` int NOT NULL,
  `sueldo_base` decimal(10,2) NOT NULL,
  `bonos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `horas_extra` decimal(10,2) NOT NULL DEFAULT '0.00',
  `afp_onp` decimal(10,2) NOT NULL DEFAULT '0.00',
  `impuesto_renta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `neto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_detalle`),
  UNIQUE KEY `uk_planilla_empleado` (`id_planilla`,`id_empleado`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `detalle_planilla_ibfk_1` FOREIGN KEY (`id_planilla`) REFERENCES `planilla_mensual` (`id_planilla`) ON DELETE CASCADE,
  CONSTRAINT `detalle_planilla_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_planilla`
--

LOCK TABLES `detalle_planilla` WRITE;
/*!40000 ALTER TABLE `detalle_planilla` DISABLE KEYS */;
INSERT INTO `detalle_planilla` VALUES (1,1,1,3000.00,150.00,90.00,413.10,259.20,2567.70),(2,1,2,3000.00,150.00,90.00,413.10,259.20,2567.70),(3,1,3,3000.00,150.00,90.00,413.10,259.20,2567.70),(4,1,4,3000.00,150.00,90.00,413.10,259.20,2567.70);
/*!40000 ALTER TABLE `detalle_planilla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documento_auditoria`
--

DROP TABLE IF EXISTS `documento_auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documento_auditoria` (
  `id_documento` int NOT NULL AUTO_INCREMENT,
  `tabla_referencia` varchar(50) NOT NULL,
  `id_referencia` int NOT NULL,
  `ruta_archivo` varchar(255) NOT NULL,
  `usuario_creador` int NOT NULL,
  `fecha_carga` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento`),
  KEY `usuario_creador` (`usuario_creador`),
  CONSTRAINT `documento_auditoria_ibfk_1` FOREIGN KEY (`usuario_creador`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documento_auditoria`
--

LOCK TABLES `documento_auditoria` WRITE;
/*!40000 ALTER TABLE `documento_auditoria` DISABLE KEYS */;
INSERT INTO `documento_auditoria` VALUES (1,'siniestro',1,'fotos/siniestro1_evidencia.jpg',5,'2026-05-15 22:49:10'),(2,'siniestro',2,'documentos/siniestro2_informe.pdf',5,'2026-05-15 22:49:10'),(3,'poliza',1,'contratos/poliza1_firmada.pdf',5,'2026-05-15 22:49:10'),(4,'poliza',2,'contratos/poliza2_anexo.pdf',5,'2026-05-15 22:49:10'),(5,'cliente',1,'identidad/cliente1_dni.jpg',5,'2026-05-15 22:49:10');
/*!40000 ALTER TABLE `documento_auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `id_empleado` int NOT NULL AUTO_INCREMENT,
  `id_persona` int NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `sueldo_base` decimal(10,2) NOT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `id_jefe` int DEFAULT NULL,
  `dias_vacaciones` int NOT NULL DEFAULT '0',
  `estado_empleado` enum('ACTIVO','VACACIONES','LICENCIA','RETIRADO') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_empleado`),
  UNIQUE KEY `id_persona` (`id_persona`),
  KEY `id_jefe` (`id_jefe`),
  CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE,
  CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`id_jefe`) REFERENCES `empleado` (`id_empleado`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,2,'Demo comercial','COMERCIAL',3000.00,'2024-05-15',NULL,0,'ACTIVO'),(2,3,'Demo tecnico','TECNICO',3000.00,'2024-05-15',NULL,0,'ACTIVO'),(3,4,'Demo operativo','OPERATIVO',3000.00,'2024-05-15',NULL,0,'ACTIVO'),(4,5,'Demo ejecutivo','EJECUTIVO',3000.00,'2024-05-15',NULL,0,'ACTIVO'),(5,10,'Perito senior','TECNICO',4500.00,'2025-05-15',NULL,0,'ACTIVO');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endoso_poliza`
--

DROP TABLE IF EXISTS `endoso_poliza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `endoso_poliza` (
  `id_endoso` int NOT NULL AUTO_INCREMENT,
  `id_poliza` int NOT NULL,
  `tipo_cambio` varchar(100) NOT NULL,
  `descripcion_cambio` text NOT NULL,
  `estado_aprobacion` enum('PENDIENTE','APROBADO','RECHAZADO') NOT NULL DEFAULT 'PENDIENTE',
  `fecha_solicitud` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_endoso`),
  KEY `id_poliza` (`id_poliza`),
  CONSTRAINT `endoso_poliza_ibfk_1` FOREIGN KEY (`id_poliza`) REFERENCES `poliza` (`id_poliza`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endoso_poliza`
--

LOCK TABLES `endoso_poliza` WRITE;
/*!40000 ALTER TABLE `endoso_poliza` DISABLE KEYS */;
/*!40000 ALTER TABLE `endoso_poliza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS `factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `factura` (
  `id_factura` int NOT NULL AUTO_INCREMENT,
  `tipo` enum('FACTURA','BOLETA','NOTA_CREDITO') NOT NULL,
  `serie` varchar(10) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `total` decimal(12,2) NOT NULL,
  `fecha_emision` date NOT NULL,
  `estado` enum('EMITIDA','PAGADA','ANULADA') NOT NULL DEFAULT 'EMITIDA',
  PRIMARY KEY (`id_factura`),
  UNIQUE KEY `uk_factura_serie_numero` (`serie`,`numero`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

LOCK TABLES `factura` WRITE;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` VALUES (1,'FACTURA','F001','00001',1,1500.00,'2026-04-25','PAGADA'),(2,'FACTURA','F001','00002',1,2200.00,'2026-04-30','PAGADA'),(3,'BOLETA','B001','00010',1,950.00,'2026-05-10','EMITIDA'),(4,'FACTURA','F001','00003',1,3300.00,'2026-05-12','EMITIDA'),(5,'NOTA_CREDITO','NC01','00001',1,500.00,'2026-05-14','EMITIDA');
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flujo_caja_tesoreria`
--

DROP TABLE IF EXISTS `flujo_caja_tesoreria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flujo_caja_tesoreria` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `tipo_flujo` enum('INGRESO','EGRESO') NOT NULL,
  `concepto` varchar(150) NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `estado_aprobacion` enum('PENDIENTE','APROBADO','EJECUTADO') NOT NULL DEFAULT 'PENDIENTE',
  `fecha_programada` date NOT NULL,
  PRIMARY KEY (`id_movimiento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flujo_caja_tesoreria`
--

LOCK TABLES `flujo_caja_tesoreria` WRITE;
/*!40000 ALTER TABLE `flujo_caja_tesoreria` DISABLE KEYS */;
INSERT INTO `flujo_caja_tesoreria` VALUES (1,'INGRESO','Cobro primas mensuales',45000.00,'EJECUTADO','2026-05-15'),(2,'INGRESO','Cobro primas atrasadas',12000.00,'APROBADO','2026-05-10'),(3,'EGRESO','Pago comisiones agentes',18000.00,'EJECUTADO','2026-05-05'),(4,'EGRESO','Reembolso siniestros aprobados',32000.00,'APROBADO','2026-04-30'),(5,'EGRESO','Renovación licencias software',8500.00,'PENDIENTE','2026-04-25'),(6,'INGRESO','Reaseguro recuperación',6500.00,'PENDIENTE','2026-04-20');
/*!40000 ALTER TABLE `flujo_caja_tesoreria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_cotizacion`
--

DROP TABLE IF EXISTS `lead_cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_cotizacion` (
  `id_cotizacion` int NOT NULL AUTO_INCREMENT,
  `id_empleado_agente` int NOT NULL,
  `producto_interes` enum('VEHICULAR','SALUD','VIDA','HOGAR','VIAJE','EMPRESA') NOT NULL,
  `estado_kanban` enum('NUEVO','CONTACTADO','EN_PROPUESTA','NEGOCIACION','GANADO','PERDIDO') NOT NULL DEFAULT 'NUEVO',
  `prima_estimada` decimal(10,2) DEFAULT NULL,
  `fecha_ingreso` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cotizacion`),
  KEY `id_empleado_agente` (`id_empleado_agente`),
  CONSTRAINT `lead_cotizacion_ibfk_1` FOREIGN KEY (`id_empleado_agente`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_cotizacion`
--

LOCK TABLES `lead_cotizacion` WRITE;
/*!40000 ALTER TABLE `lead_cotizacion` DISABLE KEYS */;
INSERT INTO `lead_cotizacion` VALUES (1,1,'VEHICULAR','NUEVO',1200.00,'2026-05-15 22:49:10'),(2,1,'SALUD','CONTACTADO',1800.00,'2026-05-15 22:49:10'),(3,1,'HOGAR','EN_PROPUESTA',450.00,'2026-05-15 22:49:10'),(4,1,'VIDA','NEGOCIACION',900.00,'2026-05-15 22:49:10'),(5,1,'VIAJE','GANADO',150.00,'2026-05-15 22:49:10'),(6,1,'VEHICULAR','PERDIDO',1100.00,'2026-05-15 22:49:10');
/*!40000 ALTER TABLE `lead_cotizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento_contable`
--

DROP TABLE IF EXISTS `movimiento_contable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimiento_contable` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `id_asiento` int NOT NULL,
  `id_cuenta` int NOT NULL,
  `debe` decimal(12,2) NOT NULL DEFAULT '0.00',
  `haber` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_movimiento`),
  KEY `id_asiento` (`id_asiento`),
  KEY `id_cuenta` (`id_cuenta`),
  CONSTRAINT `movimiento_contable_ibfk_1` FOREIGN KEY (`id_asiento`) REFERENCES `asiento_contable` (`id_asiento`) ON DELETE CASCADE,
  CONSTRAINT `movimiento_contable_ibfk_2` FOREIGN KEY (`id_cuenta`) REFERENCES `cuenta_contable` (`id_cuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento_contable`
--

LOCK TABLES `movimiento_contable` WRITE;
/*!40000 ALTER TABLE `movimiento_contable` DISABLE KEYS */;
INSERT INTO `movimiento_contable` VALUES (1,1,1,8500.00,0.00),(2,1,5,0.00,8500.00),(3,2,1,9200.00,0.00),(4,2,5,0.00,9200.00),(5,3,6,3200.00,0.00),(6,3,1,0.00,3200.00),(7,4,7,12500.00,0.00),(8,4,1,0.00,12500.00),(9,5,6,1500.00,0.00),(10,5,3,0.00,1500.00);
/*!40000 ALTER TABLE `movimiento_contable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nota_cliente`
--

DROP TABLE IF EXISTS `nota_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nota_cliente` (
  `id_nota` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_empleado_autor` int DEFAULT NULL,
  `texto` text NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota`),
  KEY `id_empleado_autor` (`id_empleado_autor`),
  KEY `idx_nota_cliente` (`id_cliente`,`fecha`),
  CONSTRAINT `nota_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE CASCADE,
  CONSTRAINT `nota_cliente_ibfk_2` FOREIGN KEY (`id_empleado_autor`) REFERENCES `empleado` (`id_empleado`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nota_cliente`
--

LOCK TABLES `nota_cliente` WRITE;
/*!40000 ALTER TABLE `nota_cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `nota_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacion`
--

DROP TABLE IF EXISTS `notificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificacion` (
  `id_notificacion` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `mensaje` text,
  `enlace` varchar(255) DEFAULT NULL,
  `tipo` enum('APROBACION','SINIESTRO','COBRANZA','COMISION','GENERAL') NOT NULL DEFAULT 'GENERAL',
  `leida` tinyint(1) NOT NULL DEFAULT '0',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_notificacion`),
  KEY `idx_notif_usuario` (`id_usuario`,`leida`),
  KEY `idx_notif_fecha` (`fecha`),
  CONSTRAINT `notificacion_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacion`
--

LOCK TABLES `notificacion` WRITE;
/*!40000 ALTER TABLE `notificacion` DISABLE KEYS */;
INSERT INTO `notificacion` VALUES (1,1,'Bienvenido al Sistema','Su cuenta ha sido configurada correctamente.',NULL,'GENERAL',0,'2026-05-15 22:49:09'),(2,2,'Bienvenido al Sistema','Su cuenta ha sido configurada correctamente.',NULL,'GENERAL',0,'2026-05-15 22:49:09'),(3,3,'Bienvenido al Sistema','Su cuenta ha sido configurada correctamente.',NULL,'GENERAL',0,'2026-05-15 22:49:09'),(4,4,'Bienvenido al Sistema','Su cuenta ha sido configurada correctamente.',NULL,'GENERAL',0,'2026-05-15 22:49:09'),(5,5,'Bienvenido al Sistema','Su cuenta ha sido configurada correctamente.',NULL,'GENERAL',0,'2026-05-15 22:49:09'),(6,1,'Bienvenido al portal ASEGURADO','Tu cuenta esta activa. Explora las funcionalidades.',NULL,'GENERAL',0,'2026-05-15 22:49:10'),(7,1,'Recordatorio de pagos pendientes','Revisa las cuotas por cobrar en el modulo de cobranza.',NULL,'COBRANZA',0,'2026-05-15 22:49:10'),(8,1,'Aprobaciones por revisar','Hay solicitudes pendientes que requieren tu atencion.',NULL,'APROBACION',0,'2026-05-15 22:49:10'),(9,1,'Siniestros en curso','Tienes siniestros con seguimiento activo.',NULL,'SINIESTRO',0,'2026-05-15 22:49:10'),(10,2,'Bienvenido al portal COMERCIAL','Tu cuenta esta activa. Explora las funcionalidades.',NULL,'GENERAL',0,'2026-05-15 22:49:10'),(11,2,'Recordatorio de pagos pendientes','Revisa las cuotas por cobrar en el modulo de cobranza.',NULL,'COBRANZA',0,'2026-05-15 22:49:10'),(12,2,'Aprobaciones por revisar','Hay solicitudes pendientes que requieren tu atencion.',NULL,'APROBACION',0,'2026-05-15 22:49:10'),(13,2,'Siniestros en curso','Tienes siniestros con seguimiento activo.',NULL,'SINIESTRO',0,'2026-05-15 22:49:10'),(14,3,'Bienvenido al portal TECNICO','Tu cuenta esta activa. Explora las funcionalidades.',NULL,'GENERAL',0,'2026-05-15 22:49:10'),(15,3,'Recordatorio de pagos pendientes','Revisa las cuotas por cobrar en el modulo de cobranza.',NULL,'COBRANZA',0,'2026-05-15 22:49:10'),(16,3,'Aprobaciones por revisar','Hay solicitudes pendientes que requieren tu atencion.',NULL,'APROBACION',0,'2026-05-15 22:49:10'),(17,3,'Siniestros en curso','Tienes siniestros con seguimiento activo.',NULL,'SINIESTRO',0,'2026-05-15 22:49:10'),(18,4,'Bienvenido al portal OPERATIVO','Tu cuenta esta activa. Explora las funcionalidades.',NULL,'GENERAL',0,'2026-05-15 22:49:10'),(19,4,'Recordatorio de pagos pendientes','Revisa las cuotas por cobrar en el modulo de cobranza.',NULL,'COBRANZA',0,'2026-05-15 22:49:10'),(20,4,'Aprobaciones por revisar','Hay solicitudes pendientes que requieren tu atencion.',NULL,'APROBACION',0,'2026-05-15 22:49:10'),(21,4,'Siniestros en curso','Tienes siniestros con seguimiento activo.',NULL,'SINIESTRO',0,'2026-05-15 22:49:10'),(22,5,'Bienvenido al portal EJECUTIVO','Tu cuenta esta activa. Explora las funcionalidades.',NULL,'GENERAL',0,'2026-05-15 22:49:10'),(23,5,'Recordatorio de pagos pendientes','Revisa las cuotas por cobrar en el modulo de cobranza.',NULL,'COBRANZA',0,'2026-05-15 22:49:10'),(24,5,'Aprobaciones por revisar','Hay solicitudes pendientes que requieren tu atencion.',NULL,'APROBACION',0,'2026-05-15 22:49:10'),(25,5,'Siniestros en curso','Tienes siniestros con seguimiento activo.',NULL,'SINIESTRO',0,'2026-05-15 22:49:10');
/*!40000 ALTER TABLE `notificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objetivo_corporativo`
--

DROP TABLE IF EXISTS `objetivo_corporativo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `objetivo_corporativo` (
  `id_objetivo` int NOT NULL AUTO_INCREMENT,
  `id_empleado_responsable` int NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `meta_cuantitativa` decimal(12,2) NOT NULL,
  `avance_actual` decimal(12,2) NOT NULL DEFAULT '0.00',
  `estado` enum('CUMPLIDO','EN_RIESGO','RETRASADO','EN_PROGRESO') NOT NULL DEFAULT 'EN_PROGRESO',
  PRIMARY KEY (`id_objetivo`),
  KEY `id_empleado_responsable` (`id_empleado_responsable`),
  CONSTRAINT `objetivo_corporativo_ibfk_1` FOREIGN KEY (`id_empleado_responsable`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objetivo_corporativo`
--

LOCK TABLES `objetivo_corporativo` WRITE;
/*!40000 ALTER TABLE `objetivo_corporativo` DISABLE KEYS */;
INSERT INTO `objetivo_corporativo` VALUES (1,1,'Aumentar polizas activas a 1500',1500.00,1245.00,'EN_PROGRESO'),(2,1,'Reducir siniestralidad por debajo del 4%',100.00,62.00,'EN_RIESGO'),(3,1,'Crecer cartera comercial 20%',120.00,108.00,'EN_PROGRESO'),(4,1,'Cierre del 90% de aprobaciones en 48h',90.00,75.00,'RETRASADO'),(5,1,'Implementar 3 productos nuevos en el ano',3.00,3.00,'CUMPLIDO');
/*!40000 ALTER TABLE `objetivo_corporativo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden_compra`
--

DROP TABLE IF EXISTS `orden_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orden_compra` (
  `id_orden` int NOT NULL AUTO_INCREMENT,
  `id_solicitud` int NOT NULL,
  `id_proveedor_interno` int NOT NULL,
  `monto_total` decimal(12,2) NOT NULL,
  `estado` enum('EMITIDA','RECIBIDA','CERRADA') NOT NULL DEFAULT 'EMITIDA',
  `fecha_emision` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_orden`),
  KEY `id_solicitud` (`id_solicitud`),
  KEY `id_proveedor_interno` (`id_proveedor_interno`),
  CONSTRAINT `orden_compra_ibfk_1` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud_compra` (`id_solicitud`) ON DELETE CASCADE,
  CONSTRAINT `orden_compra_ibfk_2` FOREIGN KEY (`id_proveedor_interno`) REFERENCES `proveedor_interno` (`id_proveedor_interno`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_compra`
--

LOCK TABLES `orden_compra` WRITE;
/*!40000 ALTER TABLE `orden_compra` DISABLE KEYS */;
INSERT INTO `orden_compra` VALUES (1,1,5,12500.00,'EMITIDA','2026-05-15 22:49:10'),(2,2,5,8500.00,'RECIBIDA','2026-05-15 22:49:10');
/*!40000 ALTER TABLE `orden_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persona`
--

DROP TABLE IF EXISTS `persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persona` (
  `id_persona` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `documento_identidad` varchar(20) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `contacto_emergencia_nombre` varchar(150) DEFAULT NULL,
  `contacto_emergencia_relacion` varchar(50) DEFAULT NULL,
  `contacto_emergencia_telefono` varchar(20) DEFAULT NULL,
  `contacto_emergencia_correo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_persona`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `documento_identidad` (`documento_identidad`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona`
--

LOCK TABLES `persona` WRITE;
/*!40000 ALTER TABLE `persona` DISABLE KEYS */;
INSERT INTO `persona` VALUES (1,1,'Ana','Asegurada','10000001','999000000','asegurado_demo@serena.com',NULL,NULL,NULL,NULL),(2,2,'Carlos','Comercial','10000002','999000000','comercial_demo@serena.com',NULL,NULL,NULL,NULL),(3,3,'Tomas','Tecnico','10000003','999000000','tecnico_demo@serena.com',NULL,NULL,NULL,NULL),(4,4,'Olga','Operativa','10000004','999000000','operativo_demo@serena.com',NULL,NULL,NULL,NULL),(5,5,'Elena','Ejecutiva','10000005','999000000','ejecutivo_demo@serena.com',NULL,NULL,NULL,NULL),(6,6,'Rosa','Diaz Lopez','10100001','98700001','rosa.diaz@serena.com',NULL,NULL,NULL,NULL),(7,7,'Manuel','Vega Torres','10100002','98700002','manuel.vega@serena.com',NULL,NULL,NULL,NULL),(8,8,'Lucia','Reyes Soto','10100003','98700003','lucia.reyes@serena.com',NULL,NULL,NULL,NULL),(9,9,'Carlos','Mendoza Lima','10100004','98700004','carlos.mendoza@serena.com',NULL,NULL,NULL,NULL),(10,10,'Pedro','Perito Quispe','10200001','987000001','perito@serena.com',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `persona` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `planilla_mensual`
--

DROP TABLE IF EXISTS `planilla_mensual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `planilla_mensual` (
  `id_planilla` int NOT NULL AUTO_INCREMENT,
  `periodo` varchar(7) NOT NULL,
  `total_planilla` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_descuentos` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_neto` decimal(12,2) NOT NULL DEFAULT '0.00',
  `estado` enum('PROCESADA','CERRADA') NOT NULL DEFAULT 'PROCESADA',
  `fecha_proceso` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_planilla`),
  UNIQUE KEY `periodo` (`periodo`),
  KEY `idx_planilla_periodo` (`periodo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planilla_mensual`
--

LOCK TABLES `planilla_mensual` WRITE;
/*!40000 ALTER TABLE `planilla_mensual` DISABLE KEYS */;
INSERT INTO `planilla_mensual` VALUES (1,'2026-05',12960.00,2689.20,10270.80,'PROCESADA','2026-05-15 22:49:10');
/*!40000 ALTER TABLE `planilla_mensual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poliza`
--

DROP TABLE IF EXISTS `poliza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poliza` (
  `id_poliza` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_producto` int NOT NULL,
  `prima_total` decimal(10,2) NOT NULL,
  `estado_poliza` enum('ACTIVA','PENDIENTE','VENCIDA','CANCELADA') NOT NULL DEFAULT 'PENDIENTE',
  `vigencia_inicio` date NOT NULL,
  `vigencia_fin` date NOT NULL,
  `fecha_emision` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_poliza`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `poliza_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `poliza_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `producto_seguro` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poliza`
--

LOCK TABLES `poliza` WRITE;
/*!40000 ALTER TABLE `poliza` DISABLE KEYS */;
INSERT INTO `poliza` VALUES (1,1,1,1500.00,'ACTIVA','2026-03-15','2027-03-15','2026-05-15 22:49:09'),(2,1,4,3600.00,'ACTIVA','2026-04-15','2027-04-15','2026-05-15 22:49:09'),(3,1,5,250.00,'PENDIENTE','2026-05-18','2026-06-17','2026-05-15 22:49:09'),(4,1,1,14400.00,'ACTIVA','2026-04-15','2027-04-15','2026-05-15 22:49:10'),(5,2,2,21600.00,'ACTIVA','2026-03-15','2027-03-15','2026-05-15 22:49:10');
/*!40000 ALTER TABLE `poliza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferencia_notificacion`
--

DROP TABLE IF EXISTS `preferencia_notificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferencia_notificacion` (
  `id_preferencia` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `notif_email` tinyint(1) NOT NULL DEFAULT '1',
  `notif_sms` tinyint(1) NOT NULL DEFAULT '0',
  `notif_push` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_preferencia`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `preferencia_notificacion_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferencia_notificacion`
--

LOCK TABLES `preferencia_notificacion` WRITE;
/*!40000 ALTER TABLE `preferencia_notificacion` DISABLE KEYS */;
INSERT INTO `preferencia_notificacion` VALUES (1,1,1,1,1),(2,2,1,0,1),(3,3,1,0,1),(4,4,1,0,1),(5,5,1,0,1);
/*!40000 ALTER TABLE `preferencia_notificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuesto_area`
--

DROP TABLE IF EXISTS `presupuesto_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presupuesto_area` (
  `id_presupuesto` int NOT NULL AUTO_INCREMENT,
  `area` varchar(100) NOT NULL,
  `presupuesto_asignado` decimal(12,2) NOT NULL,
  `monto_ejecutado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `alertas_sobreconsumo` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_presupuesto`),
  UNIQUE KEY `area` (`area`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuesto_area`
--

LOCK TABLES `presupuesto_area` WRITE;
/*!40000 ALTER TABLE `presupuesto_area` DISABLE KEYS */;
INSERT INTO `presupuesto_area` VALUES (1,'COMERCIAL',150000.00,60000.00,0),(2,'TECNICO',200000.00,80000.00,0),(3,'OPERATIVO',100000.00,40000.00,0),(4,'EJECUTIVO',80000.00,32000.00,0),(5,'MARKETING',50000.00,20000.00,0);
/*!40000 ALTER TABLE `presupuesto_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto_seguro`
--

DROP TABLE IF EXISTS `producto_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto_seguro` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo_seguro` enum('VEHICULAR','SALUD','VIDA','HOGAR','VIAJE','EMPRESA') NOT NULL,
  `prima_base` decimal(10,2) NOT NULL,
  `limites_cobertura` text,
  `restricciones_edad` int NOT NULL DEFAULT '18',
  `tasas` decimal(5,2) DEFAULT '0.00',
  `estado` enum('ACTIVO','INACTIVO') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_seguro`
--

LOCK TABLES `producto_seguro` WRITE;
/*!40000 ALTER TABLE `producto_seguro` DISABLE KEYS */;
INSERT INTO `producto_seguro` VALUES (1,'Auto Total Plus','VEHICULAR',1200.00,NULL,18,0.00,'ACTIVO'),(2,'Salud Premium','SALUD',1800.00,NULL,18,0.00,'ACTIVO'),(3,'Vida Inversión','VIDA',900.00,NULL,18,0.00,'ACTIVO'),(4,'Hogar Seguro','HOGAR',450.00,NULL,18,0.00,'ACTIVO'),(5,'Viajero Global','VIAJE',150.00,NULL,18,0.00,'ACTIVO');
/*!40000 ALTER TABLE `producto_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promocion`
--

DROP TABLE IF EXISTS `promocion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocion` (
  `id_promocion` int NOT NULL AUTO_INCREMENT,
  `id_producto` int NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `descripcion` text,
  `descuento_pct` decimal(5,2) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_promocion`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `promocion_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `producto_seguro` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocion`
--

LOCK TABLES `promocion` WRITE;
/*!40000 ALTER TABLE `promocion` DISABLE KEYS */;
INSERT INTO `promocion` VALUES (1,1,'Auto sin enganche 20%','Descuento solo para nuevos clientes vehiculares.',20.00,'2026-05-10','2026-06-09',1),(2,2,'Salud familiar - mes gratis','Contrata salud premium y obten un mes sin costo.',15.00,'2026-05-05','2026-06-04',1),(3,3,'Vida + Ahorro','Inversion respaldada con cobertura extendida.',10.00,'2026-05-12','2026-06-14',1),(4,4,'Hogar protegido al 100%','Renueva tu hogar con cobertura total a precio especial.',12.50,'2026-05-14','2026-06-29',1),(5,5,'Viaje internacional 25% off','Viaja seguro a cualquier destino con respaldo total.',25.00,'2026-05-13','2026-05-30',1);
/*!40000 ALTER TABLE `promocion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_interno`
--

DROP TABLE IF EXISTS `proveedor_interno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor_interno` (
  `id_proveedor_interno` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `ruc` varchar(20) NOT NULL,
  `rubro` varchar(100) NOT NULL,
  `contacto` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `estado` enum('ACTIVO','INACTIVO') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_proveedor_interno`),
  UNIQUE KEY `ruc` (`ruc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_interno`
--

LOCK TABLES `proveedor_interno` WRITE;
/*!40000 ALTER TABLE `proveedor_interno` DISABLE KEYS */;
INSERT INTO `proveedor_interno` VALUES (1,'Suministros Andinos SAC','20512345671','Oficina','Lucia Diaz','987654001','ventas@andinos.pe','ACTIVO'),(2,'TI Soluciones Peru','20512345672','Tecnologia','Pedro Mejia','987654002','comercial@tisoluciones.pe','ACTIVO'),(3,'Servicios Generales Lima','20512345673','Servicios','Sara Aliaga','987654003','contacto@sglima.pe','ACTIVO'),(4,'Mobiliario Corporativo','20512345674','Mobiliario','Jose Tello','987654004','ventas@mobiliario.pe','ACTIVO'),(5,'Marketing 360','20512345675','Marketing','Rosa Cabrera','987654005','info@marketing360.pe','ACTIVO');
/*!40000 ALTER TABLE `proveedor_interno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor_red`
--

DROP TABLE IF EXISTS `proveedor_red`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor_red` (
  `id_proveedor` int NOT NULL AUTO_INCREMENT,
  `rubro` enum('CLINICA','TALLER','GRUA','ABOGADO','OTROS') NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `rating_interno` decimal(3,2) DEFAULT NULL,
  `estado` enum('ACTIVO','SUSPENDIDO') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_red`
--

LOCK TABLES `proveedor_red` WRITE;
/*!40000 ALTER TABLE `proveedor_red` DISABLE KEYS */;
INSERT INTO `proveedor_red` VALUES (1,'CLINICA','Clínica San Pablo','Arequipa',NULL,'ACTIVO'),(2,'TALLER','Sur Motors','Arequipa',NULL,'ACTIVO'),(3,'GRUA','Auxilio Rápido','Lima',NULL,'ACTIVO'),(4,'CLINICA','Clínica Delgado','Lima',NULL,'ACTIVO'),(5,'TALLER','Mecánica Pro','Arequipa',NULL,'ACTIVO');
/*!40000 ALTER TABLE `proveedor_red` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reaseguro`
--

DROP TABLE IF EXISTS `reaseguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reaseguro` (
  `id_reaseguro` int NOT NULL AUTO_INCREMENT,
  `id_poliza` int NOT NULL,
  `riesgo_retenido` decimal(10,2) NOT NULL,
  `riesgo_cedido` decimal(10,2) NOT NULL,
  `reaseguradora_asociada` varchar(150) NOT NULL,
  PRIMARY KEY (`id_reaseguro`),
  KEY `id_poliza` (`id_poliza`),
  CONSTRAINT `reaseguro_ibfk_1` FOREIGN KEY (`id_poliza`) REFERENCES `poliza` (`id_poliza`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reaseguro`
--

LOCK TABLES `reaseguro` WRITE;
/*!40000 ALTER TABLE `reaseguro` DISABLE KEYS */;
INSERT INTO `reaseguro` VALUES (1,1,1050.00,450.00,'Mapfre Re'),(2,2,2520.00,1080.00,'Munich Re'),(3,3,175.00,75.00,'Swiss Re'),(4,4,10080.00,4320.00,'Hannover Re'),(5,5,15120.00,6480.00,'Scor SE');
/*!40000 ALTER TABLE `reaseguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riesgo_corporativo`
--

DROP TABLE IF EXISTS `riesgo_corporativo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `riesgo_corporativo` (
  `id_riesgo` int NOT NULL AUTO_INCREMENT,
  `tipo` enum('CONCENTRACION','SINIESTRALIDAD','MORA','PROVEEDOR','REGULATORIO','OTRO') NOT NULL,
  `descripcion` text NOT NULL,
  `severidad` enum('BAJA','MEDIA','ALTA','CRITICA') NOT NULL DEFAULT 'MEDIA',
  `area_afectada` varchar(100) DEFAULT NULL,
  `fecha_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `registrado_por` int DEFAULT NULL,
  PRIMARY KEY (`id_riesgo`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_riesgo_severidad` (`severidad`,`fecha_registro`),
  CONSTRAINT `riesgo_corporativo_ibfk_1` FOREIGN KEY (`registrado_por`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riesgo_corporativo`
--

LOCK TABLES `riesgo_corporativo` WRITE;
/*!40000 ALTER TABLE `riesgo_corporativo` DISABLE KEYS */;
INSERT INTO `riesgo_corporativo` VALUES (1,'CONCENTRACION','Mas del 55% de las polizas vendidas en Lima provienen del producto Vehicular. Riesgo de saturacion del mercado.','ALTA','Comercial','2026-05-15 22:49:09',5),(2,'SINIESTRALIDAD','Incremento del 12% en siniestros vehiculares en la zona norte durante el ultimo trimestre.','MEDIA','Tecnico','2026-05-15 22:49:09',5),(3,'MORA','Cartera morosa supera el 8%. Reforzar campania de cobranza preventiva antes del cierre del semestre.','MEDIA','Finanzas','2026-05-15 22:49:09',5),(4,'PROVEEDOR','Dependencia de un solo taller para reparaciones vehiculares en Lima Sur. Buscar al menos dos alternativas.','ALTA','Operaciones','2026-05-15 22:49:09',5),(5,'REGULATORIO','Nueva resolucion SBS exige reportes mensuales de reservas tecnicas. Plazo de adecuacion: 60 dias.','CRITICA','Cumplimiento','2026-05-15 22:49:09',5);
/*!40000 ALTER TABLE `riesgo_corporativo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siniestro`
--

DROP TABLE IF EXISTS `siniestro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `siniestro` (
  `id_siniestro` int NOT NULL AUTO_INCREMENT,
  `id_poliza` int NOT NULL,
  `id_empleado_analista` int DEFAULT NULL,
  `tipo_incidente` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_ocurrencia` date NOT NULL,
  `fecha_reporte` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado_resolucion` enum('REPORTADO','EN_REVISION','INSPECCION','APROBADO','RECHAZADO','LIQUIDADO') NOT NULL DEFAULT 'REPORTADO',
  `monto_reclamado` decimal(10,2) NOT NULL,
  `observaciones_perito` text,
  `monto_estimado_perito` decimal(12,2) DEFAULT NULL,
  `informe_tecnico` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_siniestro`),
  KEY `id_poliza` (`id_poliza`),
  KEY `id_empleado_analista` (`id_empleado_analista`),
  CONSTRAINT `siniestro_ibfk_1` FOREIGN KEY (`id_poliza`) REFERENCES `poliza` (`id_poliza`),
  CONSTRAINT `siniestro_ibfk_2` FOREIGN KEY (`id_empleado_analista`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siniestro`
--

LOCK TABLES `siniestro` WRITE;
/*!40000 ALTER TABLE `siniestro` DISABLE KEYS */;
INSERT INTO `siniestro` VALUES (1,1,NULL,'Choque o Incidente Menor','Reporte de prueba generado por el sistema','2026-05-10','2026-05-15 22:49:09','REPORTADO',1500.00,NULL,NULL,NULL),(2,2,NULL,'Choque o Incidente Menor','Reporte de prueba generado por el sistema','2026-05-10','2026-05-15 22:49:09','REPORTADO',1500.00,NULL,NULL,NULL),(3,3,NULL,'Choque o Incidente Menor','Reporte de prueba generado por el sistema','2026-05-10','2026-05-15 22:49:09','REPORTADO',1500.00,NULL,NULL,NULL),(4,1,NULL,'Robo total vehiculo','Vehiculo sustraido en zona comercial','2026-05-05','2026-05-15 22:49:10','EN_REVISION',18500.00,NULL,NULL,NULL),(5,2,NULL,'Choque por alcance','Daño en parachoques trasero','2026-05-09','2026-05-15 22:49:10','INSPECCION',3200.00,NULL,NULL,NULL);
/*!40000 ALTER TABLE `siniestro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siniestro_proveedor`
--

DROP TABLE IF EXISTS `siniestro_proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `siniestro_proveedor` (
  `id_siniestro` int NOT NULL,
  `id_proveedor` int NOT NULL,
  `costo_servicio` decimal(10,2) NOT NULL,
  `fecha_asignacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_siniestro`,`id_proveedor`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `siniestro_proveedor_ibfk_1` FOREIGN KEY (`id_siniestro`) REFERENCES `siniestro` (`id_siniestro`) ON DELETE CASCADE,
  CONSTRAINT `siniestro_proveedor_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor_red` (`id_proveedor`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siniestro_proveedor`
--

LOCK TABLES `siniestro_proveedor` WRITE;
/*!40000 ALTER TABLE `siniestro_proveedor` DISABLE KEYS */;
INSERT INTO `siniestro_proveedor` VALUES (1,1,850.00,'2026-05-15 22:49:10'),(2,2,950.00,'2026-05-14 22:49:10'),(3,3,1050.00,'2026-05-13 22:49:10'),(4,4,1150.00,'2026-05-12 22:49:10'),(5,5,1250.00,'2026-05-11 22:49:10');
/*!40000 ALTER TABLE `siniestro_proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitud_compra`
--

DROP TABLE IF EXISTS `solicitud_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitud_compra` (
  `id_solicitud` int NOT NULL AUTO_INCREMENT,
  `area` varchar(100) NOT NULL,
  `producto` varchar(200) NOT NULL,
  `descripcion` text,
  `monto_estimado` decimal(12,2) NOT NULL,
  `prioridad` enum('BAJA','MEDIA','ALTA') NOT NULL DEFAULT 'MEDIA',
  `estado` enum('PENDIENTE','APROBADO','RECHAZADO','COMPRADO') NOT NULL DEFAULT 'PENDIENTE',
  `id_empleado_solicitante` int DEFAULT NULL,
  `fecha_solicitud` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_solicitud`),
  KEY `id_empleado_solicitante` (`id_empleado_solicitante`),
  KEY `idx_solicitud_estado` (`estado`,`fecha_solicitud`),
  CONSTRAINT `solicitud_compra_ibfk_1` FOREIGN KEY (`id_empleado_solicitante`) REFERENCES `empleado` (`id_empleado`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_compra`
--

LOCK TABLES `solicitud_compra` WRITE;
/*!40000 ALTER TABLE `solicitud_compra` DISABLE KEYS */;
INSERT INTO `solicitud_compra` VALUES (1,'TI','Laptops para nuevos empleados','5 laptops Ryzen 7',12500.00,'ALTA','APROBADO',1,'2026-05-15 22:49:10'),(2,'Marketing','Campaña digital Q3','Pauta en redes sociales por 3 meses',8500.00,'MEDIA','COMPRADO',1,'2026-05-15 22:49:10'),(3,'Operaciones','Mobiliario sala de reuniones','Mesa y 8 sillas ergonomicas',4200.00,'BAJA','PENDIENTE',1,'2026-05-15 22:49:10'),(4,'RRHH','Capacitacion de liderazgo','Curso externo para 4 jefaturas',3600.00,'MEDIA','RECHAZADO',1,'2026-05-15 22:49:10'),(5,'Finanzas','Auditoria externa','Servicio anual de auditoria',15000.00,'ALTA','PENDIENTE',1,'2026-05-15 22:49:10');
/*!40000 ALTER TABLE `solicitud_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `portal_acceso` enum('ASEGURADO','COMERCIAL','TECNICO','OPERATIVO','EJECUTIVO') NOT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `estado` enum('ACTIVO','INACTIVO','BLOQUEADO') NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'asegurado_demo','$2a$10$Vm9qqf1l2yznWx8cg7eur.BCBcDWiy4ESYDmM5L0U08ubygoICPVK','ASEGURADO',NULL,'ACTIVO'),(2,'comercial_demo','$2a$10$XmQfQ/XejT6VsfctzjofKOYx4cbo1lIdjIOyzntYVyQP7Ij9Qnn5.','COMERCIAL',NULL,'ACTIVO'),(3,'tecnico_demo','$2a$10$wCofd4C28leoYJTHn8vD1eDOUCqE0iSJiy2gA0Z9BwFh5WQGmXvoS','TECNICO',NULL,'ACTIVO'),(4,'operativo_demo','$2a$10$CwYzDerb6eJDRxZGKtY0FurswT/fdIkD/5UyTzwqZ7lIBVsvGdgNq','OPERATIVO',NULL,'ACTIVO'),(5,'ejecutivo_demo','$2a$10$1a2ZGKdREXeuASwokefQseM17KxVtkc0VxtJuRjM3X9n1wy6B.K6u','EJECUTIVO',NULL,'ACTIVO'),(6,'asegurado2_demo','$2a$10$OvkrkeKbQK8lx6wVKJPCke3unCg6bPcEAoxEVJOuf/QrfBGu23kNK','ASEGURADO',NULL,'ACTIVO'),(7,'asegurado3_demo','$2a$10$zrvaVPfSB710TSd/ZA7TjewE1QxUH.qhmcPO7z/jBfF0UVHoTjNyi','ASEGURADO',NULL,'ACTIVO'),(8,'asegurado4_demo','$2a$10$CdxQrS8snI6kFgyGazu6neBqDrygA7QJ23JKiSFqeFX68wopMNexa','ASEGURADO',NULL,'ACTIVO'),(9,'asegurado5_demo','$2a$10$HyUlBXKGd1KAi2P0oXJzGumkyWh97gsVU5a4J58sFh8j6UPOXbdwC','ASEGURADO',NULL,'ACTIVO'),(10,'perito_demo','$2a$10$oWyKU4GB9InF0gj0reZu9.Wpl/aZULne5uAKCeOnBc.eoO2aNFCnS','TECNICO',NULL,'ACTIVO');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validacion_documental`
--

DROP TABLE IF EXISTS `validacion_documental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validacion_documental` (
  `id_validacion` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_documento` int DEFAULT NULL,
  `estado` enum('PENDIENTE','APROBADO','RECHAZADO','CORRECCION') NOT NULL DEFAULT 'PENDIENTE',
  `motivo_rechazo` text,
  `id_empleado_validador` int DEFAULT NULL,
  `fecha_ingreso` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_resolucion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_validacion`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_documento` (`id_documento`),
  KEY `id_empleado_validador` (`id_empleado_validador`),
  KEY `idx_validacion_estado` (`estado`,`fecha_ingreso`),
  CONSTRAINT `validacion_documental_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`) ON DELETE CASCADE,
  CONSTRAINT `validacion_documental_ibfk_2` FOREIGN KEY (`id_documento`) REFERENCES `documento_auditoria` (`id_documento`) ON DELETE SET NULL,
  CONSTRAINT `validacion_documental_ibfk_3` FOREIGN KEY (`id_empleado_validador`) REFERENCES `empleado` (`id_empleado`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validacion_documental`
--

LOCK TABLES `validacion_documental` WRITE;
/*!40000 ALTER TABLE `validacion_documental` DISABLE KEYS */;
INSERT INTO `validacion_documental` VALUES (1,1,NULL,'PENDIENTE',NULL,NULL,'2026-05-15 22:49:10',NULL),(2,1,NULL,'PENDIENTE',NULL,NULL,'2026-05-15 22:49:10',NULL),(3,1,NULL,'APROBADO',NULL,2,'2026-05-15 22:49:10','2026-05-15 20:49:10'),(4,1,NULL,'RECHAZADO','El DNI cargado esta vencido. Solicitar version vigente.',2,'2026-05-15 22:49:10','2026-05-15 20:49:10'),(5,1,NULL,'CORRECCION','La foto del documento esta borrosa. Por favor reenviar.',2,'2026-05-15 22:49:10','2026-05-15 20:49:10');
/*!40000 ALTER TABLE `validacion_documental` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-15 22:50:05
